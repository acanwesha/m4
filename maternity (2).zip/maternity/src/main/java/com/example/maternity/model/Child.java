package com.example.maternity.model;

import java.io.Serializable;
import javax.persistence.*;
import java.util.List;


/**
 * The persistent class for the child database table.
 * 
 */
@Entity
@NamedQuery(name="Child.findAll", query="SELECT c FROM Child c")
public class Child implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	private int childID;

	private String fin;

	@Column(name="first_name")
	private String firstName;

	@Column(name="last_name")
	private String lastName;

	private String mrn;

	//bi-directional many-to-one association to BabyResultTable
	@OneToMany(mappedBy="child",fetch = FetchType.EAGER)
	private List<BabyResultTable> babyResultTables;

	//bi-directional many-to-one association to Patient
	@ManyToOne
	@JoinColumn(name="PatientID")
	private Patient patient;

	//bi-directional many-to-one association to PatientResult
	@OneToMany(mappedBy="child")
	private List<PatientResult> patientResults;

	public Child() {
	}

	public int getChildID() {
		return this.childID;
	}

	public void setChildID(int childID) {
		this.childID = childID;
	}

	public String getFin() {
		return this.fin;
	}

	public void setFin(String fin) {
		this.fin = fin;
	}

	public String getFirstName() {
		return this.firstName;
	}

	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	public String getLastName() {
		return this.lastName;
	}

	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

	public String getMrn() {
		return this.mrn;
	}

	public void setMrn(String mrn) {
		this.mrn = mrn;
	}

	public List<BabyResultTable> getBabyResultTables() {
		return this.babyResultTables;
	}

	public void setBabyResultTables(List<BabyResultTable> babyResultTables) {
		this.babyResultTables = babyResultTables;
	}

	public BabyResultTable addBabyResultTable(BabyResultTable babyResultTable) {
		getBabyResultTables().add(babyResultTable);
		babyResultTable.setChild(this);

		return babyResultTable;
	}

	public BabyResultTable removeBabyResultTable(BabyResultTable babyResultTable) {
		getBabyResultTables().remove(babyResultTable);
		babyResultTable.setChild(null);

		return babyResultTable;
	}

	public Patient getPatient() {
		return this.patient;
	}

	public void setPatient(Patient patient) {
		this.patient = patient;
	}

	public List<PatientResult> getPatientResults() {
		return this.patientResults;
	}

	public void setPatientResults(List<PatientResult> patientResults) {
		this.patientResults = patientResults;
	}

	public PatientResult addPatientResult(PatientResult patientResult) {
		getPatientResults().add(patientResult);
		patientResult.setChild(this);

		return patientResult;
	}

	public PatientResult removePatientResult(PatientResult patientResult) {
		getPatientResults().remove(patientResult);
		patientResult.setChild(null);

		return patientResult;
	}

}