package com.example.maternity.model;

import java.io.Serializable;
import javax.persistence.*;
import java.sql.Timestamp;


/**
 * The persistent class for the baby_result_table database table.
 * 
 */
@Entity
@Table(name="baby_result_table")
@NamedQuery(name="BabyResultTable.findAll", query="SELECT b FROM BabyResultTable b")
public class BabyResultTable implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	private int copyID;

	private String category_name;

	private Timestamp dateTime;

	private String result_name;

	private String value;

	//bi-directional many-to-one association to Child
	@ManyToOne
	@JoinColumn(name="ChildID")
	private Child child;

	public BabyResultTable() {
	}

	public int getCopyID() {
		return this.copyID;
	}

	public void setCopyID(int copyID) {
		this.copyID = copyID;
	}

	public String getCategory_name() {
		return this.category_name;
	}

	public void setCategory_name(String category_name) {
		this.category_name = category_name;
	}

	public Timestamp getDateTime() {
		return this.dateTime;
	}

	public void setDateTime(Timestamp dateTime) {
		this.dateTime = dateTime;
	}

	public String getResult_name() {
		return this.result_name;
	}

	public void setResult_name(String result_name) {
		this.result_name = result_name;
	}

	public String getValue() {
		return this.value;
	}

	public void setValue(String value) {
		this.value = value;
	}

	public Child getChild() {
		return this.child;
	}

	public void setChild(Child child) {
		this.child = child;
	}

}