package com.example.maternity.model;

import javax.persistence.*;
import java.io.Serializable;
import java.util.Collection;
import java.util.List;
import java.util.Objects;

@NamedQueries({
        @NamedQuery(name = "Patient.findById", query = "select p from Patient p where p.patientID = :patientid" )

})
@Entity
@NamedQuery(name="Patient.findAll", query="SELECT p FROM Patient p")
public class Patient implements Serializable {
    private static final long serialVersionUID = 1L;

    @Id
    private int patientID;

    private String fin;

    @Column(name="first_name")
    private String firstName;

    @Column(name="last_name")
    private String lastName;

    private String mrn;

    //bi-directional many-to-one association to Child
    @OneToMany(mappedBy="patient",fetch = FetchType.EAGER)
    private List<Child> childs;

    //bi-directional many-to-one association to PatientResult
    @OneToMany(mappedBy="patient" )
    private List<PatientResult> patientResults;

    public Patient() {
    }

    public int getPatientID() {
        return this.patientID;
    }

    public void setPatientID(int patientID) {
        this.patientID = patientID;
    }

    public String getFin() {
        return this.fin;
    }

    public void setFin(String fin) {
        this.fin = fin;
    }

    public String getFirstName() {
        return this.firstName;
    }

    public void setFirstName(String firstName) {
        this.firstName = firstName;
    }

    public String getLastName() {
        return this.lastName;
    }

    public void setLastName(String lastName) {
        this.lastName = lastName;
    }

    public String getMrn() {
        return this.mrn;
    }

    public void setMrn(String mrn) {
        this.mrn = mrn;
    }

    public List<Child> getChilds() {
        return this.childs;
    }

    public void setChilds(List<Child> childs) {
        this.childs = childs;
    }

    public Child addChild(Child child) {
        getChilds().add(child);
        child.setPatient(this);

        return child;
    }

    public Child removeChild(Child child) {
        getChilds().remove(child);
        child.setPatient(null);

        return child;
    }

    public List<PatientResult> getPatientResults() {
        return this.patientResults;
    }

    public void setPatientResults(List<PatientResult> patientResults) {
        this.patientResults = patientResults;
    }

    public PatientResult addPatientResult(PatientResult patientResult) {
        getPatientResults().add(patientResult);
        patientResult.setPatient(this);

        return patientResult;
    }

    public PatientResult removePatientResult(PatientResult patientResult) {
        getPatientResults().remove(patientResult);
        patientResult.setPatient(null);

        return patientResult;
    }

}