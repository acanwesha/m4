package com.example.maternity.model;

import java.io.Serializable;
import javax.persistence.*;
import java.util.List;


/**
 * The persistent class for the patient_result database table.
 * patientId
 */
@Entity
@Table(name="patient_result")
//@NamedQuery({name="PatientResult.findAll", query="SELECT p FROM PatientResult p"})
@NamedQueries({ @NamedQuery(name = "PatientResult.findAll", query = "SELECT pr FROM PatientResult pr"),
		@NamedQuery(name = "PatientResult.findByPatientResultId", query = "select pr from PatientResult pr where pr.patient_resultID = :patient_resultID")
})
public class PatientResult implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	private int patient_resultID;

	private String value;

	//bi-directional many-to-one association to Patient
	@ManyToOne
	@JoinColumn(name="PatientID" ,insertable = false, updatable = false)
	private Patient patient;

	//bi-directional many-to-one association to Child
	@ManyToOne
	@JoinColumn(name="ChildID")
	private Child child;

	//bi-directional many-to-one association to ResultDetail
	@OneToMany(mappedBy="patientResult1")
	private List<ResultDetail> resultDetails1;



	public PatientResult() {
	}

	public int getPatient_resultID() {
		return this.patient_resultID;
	}

	public void setPatient_resultID(int patient_resultID) {
		this.patient_resultID = patient_resultID;
	}

	public String getValue() {
		return this.value;
	}

	public void setValue(String value) {
		this.value = value;
	}

	public Patient getPatient() {
		return this.patient;
	}

	public void setPatient(Patient patient) {
		this.patient = patient;
	}

	public Child getChild() {
		return this.child;
	}

	public void setChild(Child child) {
		this.child = child;
	}

	public List<ResultDetail> getResultDetails1() {
		return this.resultDetails1;
	}

	public void setResultDetails1(List<ResultDetail> resultDetails1) {
		this.resultDetails1 = resultDetails1;
	}

	public ResultDetail addResultDetails1(ResultDetail resultDetails1) {
		getResultDetails1().add(resultDetails1);
		resultDetails1.setPatientResult1(this);

		return resultDetails1;
	}

	public ResultDetail removeResultDetails1(ResultDetail resultDetails1) {
		getResultDetails1().remove(resultDetails1);
		resultDetails1.setPatientResult1(null);

		return resultDetails1;
	}





}