package com.example.maternity.dto;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

public class PatientResultDto {
    private PatientDto patient = new PatientDto();
    private List<ChildDto> child = new ArrayList<>();
    private List<CategoryDto> category = new ArrayList<>();
    private Date resultCopiedDateTime ;

    public PatientDto getPatient() {
        return patient;
    }

    public void setPatient(PatientDto patient) {
        this.patient = patient;
    }

    public List<ChildDto> getChild() {
        return child;
    }

    public void setChild(List<ChildDto> child) {
        this.child = child;
    }

    public List<CategoryDto> getCategory() {
        return category;
    }

    public void setCategory(List<CategoryDto> category) {
        this.category = category;
    }

    public Date getResultCopiedDateTime() {
        return resultCopiedDateTime;
    }

    public void setResultCopiedDateTime(Date resultCopiedDateTime) {
        this.resultCopiedDateTime = resultCopiedDateTime;
    }
}
