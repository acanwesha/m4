package com.example.maternity.resource;

import com.example.maternity.dao.PatientDAO;
import com.example.maternity.dao.PatientResultDAO;
import com.example.maternity.dto.PatientResultDto;
import com.example.maternity.model.Patient;

import javax.ws.rs.*;
import javax.ws.rs.core.MediaType;

@Path("resource")
public class MaternityResource {

    @GET
    @Produces(MediaType.TEXT_PLAIN)
    public String sayPlainTextHello() {
        return "Hello Welcome";
    }


    @POST
    @Path("/register")
    @Produces(MediaType.APPLICATION_JSON)
    @Consumes(MediaType.APPLICATION_JSON)
    public Patient registerPatient(Patient patient) {
        PatientDAO dao = new PatientDAO();
        Patient savedPatient = dao.persistPatient(patient);
        return savedPatient;
    }

    @GET
    @Path("/patient/{patientId}")
    @Produces(MediaType.APPLICATION_JSON)
    @Consumes(MediaType.APPLICATION_JSON)
    public PatientResultDto checkPatientResultCopiedOrNot(@PathParam("patientId") Integer patientId) {
        PatientResultDAO prDao = new PatientResultDAO();
        PatientResultDto patientResultDto = prDao.getPatientResultById(patientId);
        return patientResultDto;
    }


    @POST
    @Path("/copydata")
    @Produces(MediaType.APPLICATION_JSON)
    @Consumes(MediaType.APPLICATION_JSON)
    public Patient copyResultAssociatedWithChildMom(Patient patient) {
        PatientDAO dao = new PatientDAO();
        Patient savedPatient = dao.persistPatient(patient);
        return savedPatient;
    }
}
