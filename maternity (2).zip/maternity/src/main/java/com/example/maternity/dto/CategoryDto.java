package com.example.maternity.dto;

import com.example.maternity.model.Result;

import java.io.Serializable;
import javax.persistence.*;
import java.util.ArrayList;
import java.util.List;


/**
 * The persistent class for the category database table.
 * 
 */
public class CategoryDto implements Serializable {
	private static final long serialVersionUID = 1L;

	private int categoryID;

	private String category_name;

	private List<ResultDto> result = new ArrayList<>();

	public int getCategoryID() {
		return categoryID;
	}

	public void setCategoryID(int categoryID) {
		this.categoryID = categoryID;
	}

	public String getCategory_name() {
		return category_name;
	}

	public void setCategory_name(String category_name) {
		this.category_name = category_name;
	}

	public List<ResultDto> getResult() {
		return result;
	}

	public void setResult(List<ResultDto> result) {
		this.result = result;
	}
}