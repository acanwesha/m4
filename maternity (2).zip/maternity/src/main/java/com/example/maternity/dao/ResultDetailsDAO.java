package com.example.maternity.dao;

import com.example.maternity.model.Patient;
import com.example.maternity.model.PatientResult;
import com.example.maternity.model.Result;
import com.example.maternity.model.ResultDetail;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import java.util.List;


public class ResultDetailsDAO {
	protected static EntityManagerFactory emf = Persistence.createEntityManagerFactory("maternity");


	public ResultDetailsDAO() {
		
	}


	public Patient persistPatient(Patient patient) {
		EntityManager em = emf.createEntityManager();
		em.getTransaction().begin();
		em.persist(patient);
		em.getTransaction().commit();
		em.close();
		return patient;
	}



	public ResultDetail getResultDetailByResult(Result result) {
		EntityManager em = emf.createEntityManager();
		ResultDetail patient = (ResultDetail) em.createNamedQuery("ResultDetail.findByResult",ResultDetail.class)
				.setParameter("result", result)
				.getSingleResult();
		em.close();
		return patient;
	}




	public ResultDetail getResultDetails(PatientResult patientResult, Result result) {
		EntityManager em = emf.createEntityManager();
		ResultDetail resultDetail = (ResultDetail) em.createNamedQuery("ResultDetail.findByResultAndPatientResult")
				           .setParameter("patientResult1", patientResult)
				           .setParameter("result", result)
				           .getSingleResult();
	                     	em.close();
		return resultDetail;
	}

}
