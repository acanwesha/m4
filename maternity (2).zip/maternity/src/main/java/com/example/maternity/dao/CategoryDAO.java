package com.example.maternity.dao;

import com.example.maternity.model.Category;
import com.example.maternity.model.Patient;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import java.util.List;


public class CategoryDAO {
	protected static EntityManagerFactory emf = Persistence.createEntityManagerFactory("maternity");


	public CategoryDAO() {
		
	}




	public List<Category> getCategories() {
		EntityManager em = emf.createEntityManager();
		List<Category> categories = (List<Category>) em.createNamedQuery("Category.findAll").getResultList();
		em.close();
		return categories;
	    }

}
