package com.example.maternity.model;

import java.io.Serializable;
import javax.persistence.*;


/**
 * The persistent class for the result_details database table.
 * 
 */
@Entity
@Table(name="result_details")
//@NamedQuery(name="ResultDetail.findAll", query="SELECT r FROM ResultDetail r")
@NamedQueries({
		@NamedQuery(name="ResultDetail.findAll", query="SELECT r FROM ResultDetail r"),
		@NamedQuery(name = "ResultDetail.findByResultId", query = "select rd from ResultDetail rd where rd.result.resultID = :resultID"),
		@NamedQuery(name = "ResultDetail.findByResult", query = "select rd from ResultDetail rd where rd.result = :result"),
		@NamedQuery(name = "ResultDetail.findByResultAndPatientResult", query = "select rd from ResultDetail rd where rd.result = :result AND rd.patientResult1 =:patientResult1"),
		@NamedQuery(name = "ResultDetail.findByResultIdAndPatientResultId", query = "select rd from ResultDetail rd where rd.result.resultID = :resultID AND rd.patientResult1.patient_resultID =:patient_resultID")
})
public class ResultDetail implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	private int detailsID;

	//bi-directional many-to-one association to Result
	@ManyToOne
	@JoinColumn(name="ResultID")
	private Result result;

	//bi-directional many-to-one association to PatientResult
	@ManyToOne
	@JoinColumn(name="Patient_resultID")
	private PatientResult patientResult1;


	public ResultDetail() {
	}

	public int getDetailsID() {
		return this.detailsID;
	}

	public void setDetailsID(int detailsID) {
		this.detailsID = detailsID;
	}

	public Result getResult() {
		return this.result;
	}

	public void setResult(Result result) {
		this.result = result;
	}

	public PatientResult getPatientResult1() {
		return this.patientResult1;
	}

	public void setPatientResult1(PatientResult patientResult1) {
		this.patientResult1 = patientResult1;
	}


}