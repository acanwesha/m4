package com.example.maternity.dao;

import com.example.maternity.model.Category;
import com.example.maternity.model.Patient;
import com.example.maternity.model.Result;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import java.util.List;


public class ResultDAO {
	protected static EntityManagerFactory emf = Persistence.createEntityManagerFactory("maternity");


	public ResultDAO() {
		
	}

	public Result getResultById(Integer resultId) {
		EntityManager em = emf.createEntityManager();
		Result patient = (Result) em.createNamedQuery("Result.findById",Result.class)
				.setParameter("resultID", resultId)
				.getSingleResult();
		em.close();
		return patient;
	}

	public List<Result> getCategories(Integer categoryId) {
		EntityManager em = emf.createEntityManager();
		List<Result> result = (List<Result>) em.createNamedQuery("Result.findByCategoryId")
				              .setParameter("categoryId", categoryId)
				              .getResultList();
		em.close();
		return result;
	}

}
