package com.example.maternity.model;

import java.io.Serializable;
import javax.persistence.*;
import java.util.List;


/**
 * The persistent class for the result database table.
 * 
 */
@Entity
@NamedQueries({
		@NamedQuery(name="Result.findAll", query="SELECT r FROM Result r"),
		@NamedQuery(name = "Result.findById", query = "select r from Result r where r.resultID = :resultID" ),
		@NamedQuery(name = "Result.findByCategoryId", query = "select rs from Result rs where rs.category.categoryID = :categoryId" )
})
public class Result implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	private int resultID;

	private String result_name;

	//bi-directional many-to-one association to Category
	@ManyToOne
	@JoinColumn(name="CategoryID")
	private Category category;

	//bi-directional many-to-one association to ResultDetail
	@OneToMany(mappedBy="result")
	private List<ResultDetail> resultDetails;

	public Result() {
	}

	public int getResultID() {
		return this.resultID;
	}

	public void setResultID(int resultID) {
		this.resultID = resultID;
	}

	public String getResult_name() {
		return this.result_name;
	}

	public void setResult_name(String result_name) {
		this.result_name = result_name;
	}

	public Category getCategory() {
		return this.category;
	}

	public void setCategory(Category category) {
		this.category = category;
	}

	public List<ResultDetail> getResultDetails() {
		return this.resultDetails;
	}

	public void setResultDetails(List<ResultDetail> resultDetails) {
		this.resultDetails = resultDetails;
	}

	public ResultDetail addResultDetail(ResultDetail resultDetail) {
		getResultDetails().add(resultDetail);
		resultDetail.setResult(this);

		return resultDetail;
	}

	public ResultDetail removeResultDetail(ResultDetail resultDetail) {
		getResultDetails().remove(resultDetail);
		resultDetail.setResult(null);

		return resultDetail;
	}

}