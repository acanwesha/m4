package com.example.maternity.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

import com.example.maternity.model.Patient;


public class PatientDAO {
	protected static EntityManagerFactory emf = Persistence.createEntityManagerFactory("maternity");
	
	
	public PatientDAO() {
		
	}


	public Patient persistPatient(Patient patient) {
		EntityManager em = emf.createEntityManager();
		em.getTransaction().begin();
		em.persist(patient);
		em.getTransaction().commit();
		em.close();
		return patient;
	}

	public Patient getPatientById(Integer patientid) {
		EntityManager em = emf.createEntityManager();
		Patient patient = (Patient) em.createNamedQuery("Patient.findById",Patient.class)
				.setParameter("patientid", patientid)
				.getSingleResult();
		em.close();
		return patient;
	}

}
